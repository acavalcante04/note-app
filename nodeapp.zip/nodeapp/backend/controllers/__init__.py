# app/controllers/__init__.py
# Pode ficar vazio ou importar os controllers para facilitar o gerenciamento.
