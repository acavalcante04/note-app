// frontend/static/js/main.js
console.log("JavaScript carregado com sucesso!");
